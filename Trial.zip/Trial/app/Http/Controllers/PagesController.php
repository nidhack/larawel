<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index (){
       // return "<h1>Haaaaiiiii</h1>" ;

       $name="Ansa Antony";
       //return view('pages.index',compact('name'));

       return view('pages.index')-> with('titles',$name);
    }
    public function about (){
        // return "<h1>Haaaaiiiii</h1>" ;
        return view('pages.about');
     }
     public function services (){
        // return "<h1>Haaaaiiiii</h1>" ;
        return view('pages.services');
     }
       
    
}
