<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DbTrials extends Model
{
    //
    Public $fillable = ['title','body'];
}
