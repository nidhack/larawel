@extends('layouts.add')
@section('contents')
<h1>Haaai Ansa Antony</h1>
@endsection