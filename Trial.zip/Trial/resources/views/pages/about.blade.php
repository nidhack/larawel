@extends('layouts.add')
@section('contents')
<h5>Linomon</h5>
<h4>mathan</h4>
<h3>Pathsssss </h3>
<h2>Ayanaaaaaa <h2>
<h1>Ansaa Antony</h1>
@endsection