<html>
<head>
<title>Data</title>
</head>
<body>
<table border="2">
<tr><th>ID</th>
<th>Title</th>
<th>Body</th>
<th>Edit</th>
<th>Delete</th>
</tr>
@foreach($share as $value)
<tr>
<td>
{{$value->id}}</td>
<td>
{{$value->title}}</td>
<td>
{{$value->body}}</td>
<td><a href="{{ route('DbTrials.edit',$value->id)}}">Edit</td>
<td><form action="{{ route('DbTrials.destroy',$value->id)}}" method="post">
@csrf
@method('DELETE')
<button type="submit">Delete</button></td>
</tr>
@endforeach

</table>
</body>
</html>
