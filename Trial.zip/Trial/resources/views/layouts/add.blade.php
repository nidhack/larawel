<html>
<div>
<h3><a href="/index">Index</a>
<a href="/about">About</a>
<a href="{{ url('/services') }}">Services</a></h3>
</div>
@yield('contents')
</html>
