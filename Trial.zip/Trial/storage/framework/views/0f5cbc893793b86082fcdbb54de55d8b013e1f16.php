<body background="images/g1.jpg">

<?php $__env->startSection('contents'); ?>

<h1><marquee>Welcome</marquee></h1>
<h3><?php echo $titles; ?><br></h3>
 <?php echo e($titles); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>