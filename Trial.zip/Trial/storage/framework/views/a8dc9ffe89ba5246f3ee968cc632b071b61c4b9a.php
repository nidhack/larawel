<html>
<head>
<title>Data</title>
</head>
<body>
<table border="2">
<tr><th>ID</th>
<th>Title</th>
<th>Body</th>
<th>Edit</th>
<th>Delete</th>
</tr>
<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td>
<?php echo e($value->id); ?></td>
<td>
<?php echo e($value->title); ?></td>
<td>
<?php echo e($value->body); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
