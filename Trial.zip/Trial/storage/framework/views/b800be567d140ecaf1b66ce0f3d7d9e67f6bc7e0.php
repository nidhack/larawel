<html>
<div>
<h3><a href="/index">Index</a>
<a href="/about">About</a>
<a href="<?php echo e(url('/services')); ?>">Services</a></h3>
</div>
<?php echo $__env->yieldContent('contents'); ?>
</html>
