<html>
<head>
</head>
<body>
<form method="post" action= "<?php echo e(route('DbTrials.update',$value1->id)); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>
<table><tr><th>Title</th>
<td><input type="text" name="title" value=<?php echo e($value1->title); ?>></td><tr>
<tr><th>Body
</th>
<td><input type="text" name="body" value=<?php echo e($value1->body); ?>></td></tr>
<tr><td><input type="submit" name="submit"></td></tr>
</table>
</form>
</body>
</html>